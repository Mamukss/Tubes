package exception;

public class InputHarusAngkaException extends Exception{
    public String message(){
        return "FIELD INPUT HANYA BOLEH ANGKA !";
    }
}