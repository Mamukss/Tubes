/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interface_Control;

/**
 *
 * @author yobel
 */
public interface IShowTableBySearch <T, I> {
     T showTableBySearch(I data);
}
